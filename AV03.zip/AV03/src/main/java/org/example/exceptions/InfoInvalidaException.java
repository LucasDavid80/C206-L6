package org.example.exceptions;

public class InfoInvalidaException extends Exception{
    public InfoInvalidaException(String message){
        super(message);
    }
}
