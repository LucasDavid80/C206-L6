package org.example.interfaces;

public interface AtaqueEspecial {
    public void ataqueEspecial();
}
