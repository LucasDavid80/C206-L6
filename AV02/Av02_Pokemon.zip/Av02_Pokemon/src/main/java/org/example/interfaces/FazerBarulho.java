package org.example.interfaces;

public interface FazerBarulho {
    public void fazerBarulho();
}
