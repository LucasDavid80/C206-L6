package org.example.pokemon;

public class HeldItem {
    public String tipo;
}
