package org.example.exceptions;

public class PrecoNegativoException extends Exception {
    public PrecoNegativoException(String message) {
        super(message);
    }
}
